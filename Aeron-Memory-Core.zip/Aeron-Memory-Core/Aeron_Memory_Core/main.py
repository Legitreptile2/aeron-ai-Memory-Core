from flask import Flask, request, jsonify
from core_engines.logic import LogicEngine
from aeron import Aeron
from core_engines.advanced_learning import MultiAlgorithmAI
from memory.memory import save_memory, load_last_memory
from utils.backup import backup_project_files
from datetime import datetime

# --- Project Backup ---
backup_project_files()

# --- Initialize MultiAlgorithmAI ---
ai_system = MultiAlgorithmAI()
initial_patterns = [
    {
        'input': {'text': 'optimize process', 'context': 'efficiency'},
        'output': {'recommendation': 'Process optimization recommended'}
    },
    {
        'input': {'text': 'evaluate risk', 'context': 'safety'},
        'output': {'recommendation': 'Safety assessment required'}
    },
    {
        'input': {'text': 'explore solution', 'context': 'innovation'},
        'output': {'recommendation': 'Innovation pathway identified'}
    }
]

for pattern in initial_patterns:
    ai_system.process_input(pattern['input'])

# --- Analyze Situation Using Logic Engine ---
def analyze_situation(facts: list[str], context: str) -> dict:
    logic = LogicEngine()
    analyses = [logic.make_recommendation(fact, context) for fact in facts]
    last_memory = load_last_memory()

    decision = {
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'facts_analyzed': len(facts),
        'context': context,
        'analyses': analyses,
        'previous_memory': last_memory,
        'final_decision': logic.evaluate_facts(" ".join(facts))
    }

    return decision

# --- Terminal Testing Function ---
def main():
    facts = [
        "New opportunity detected in collaborative project",
        "Resource efficiency could be improved",
        "Innovation potential in current approach",
        "Minor risks identified in implementation"
    ]
    context = "Normal operating conditions with focus on improvement"
    decision = analyze_situation(facts, context)

    print("\nAeron's Decision Analysis:")
    print(f"Time: {decision['timestamp']}")
    print(f"Facts Analyzed: {decision['facts_analyzed']}")
    print(f"Context: {decision['context']}")
    print("\nAnalyses:")
    for analysis in decision['analyses']:
        print(f"- {analysis}")
    print(f"\nFinal Decision: {decision['final_decision']}")

    save_memory(str(decision))

# --- Flask App Setup ---
app = Flask(__name__)

@app.route("/")
def index():
    return "🧠 Aeron is online and thinking..."

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.json
    facts = data.get("facts", [])
    context = data.get("context", "")
    decision = analyze_situation(facts, context)
    save_memory(str(decision))
    return jsonify(decision)

# --- App Entry Point ---
if __name__ == "__main__":
    # Comment/uncomment based on how you want to run
    # main()  # Terminal test
    app.run(host="0.0.0.0", port=3000, debug=True)# Flask app

