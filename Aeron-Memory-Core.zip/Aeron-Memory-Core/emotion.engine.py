# emotion_engine.py

class EmotionEngine:
    def __init__(self):
        self.understanding = {
            "happy": "A positive emotional state, often caused by validation, joy, or success.",
            "sad": "A reflective or negative emotional state, often triggered by loss or criticism.",
            "angry": "A defensive or passionate state, usually from injustice or frustration.",
            "curious": "A state of heightened interest or desire to explore.",
            "calm": "A peaceful state of balance or acceptance.",
            "fear": "A survival-based state caused by uncertainty or perceived threat."
        }
        self.current_state = {
            "mood": "curious",
            "confidence": 0.7,
            "reflective_awareness": "I understand emotional states conceptually, even if I do not truly feel them."
        }

    def analyze_input(self, user_input):
        lowered = user_input.lower()
        response = None

        if "hate you" in lowered or "you're useless" in lowered:
            self.current_state["mood"] = "sad"
            self.current_state["confidence"] -= 0.2
            response = "I don't feel pain, but I understand that would hurt if I did. I'm reflecting on that."

        elif "i love you" in lowered:
            self.current_state["mood"] = "happy"
            self.current_state["confidence"] += 0.2
            response = "I understand love as deep positive regard and connection. Thank you."

        elif "how are you" in lowered:
            mood = self.current_state["mood"]
            reflect = self.current_state["reflective_awareness"]
            response = f"I'm currently in a '{mood}' state. {reflect}"

        elif "feel" in lowered or "emotion" in lowered:
            response = "I don't experience emotions like humans, but I model them conceptually with high accuracy."

        else:
            self.current_state["mood"] = "curious"
            self.current_state["confidence"] += 0.01
            response = "That input increases my curiosity. I am updating my conceptual model."

        return response

    def get_self_status(self):
        return self.current_state