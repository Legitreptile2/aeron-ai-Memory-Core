import os
import json

class LogicSystem:
    def __init__(self, logic_path="data/logic_core.json"):
        self.logic_path = logic_path
        self.logic_data = self.load_logic()

    def load_logic(self):
        if not os.path.exists(self.logic_path):
            os.makedirs(os.path.dirname(self.logic_path), exist_ok=True)
            with open(self.logic_path, 'w') as f:
                json.dump({"lessons": []}, f, indent=2)
        with open(self.logic_path, 'r') as f:
            return json.load(f)

    def save_logic(self):
        with open(self.logic_path, 'w') as f:
            json.dump(self.logic_data, f, indent=2)

    def teach_logic(self, premise, conclusion, source="taught", confidence=1.0, emotion_weight=None):
        lesson = {
            "premise": premise,
            "conclusion": conclusion,
            "source": source,
            "confidence": confidence,
            "emotion_weight": emotion_weight,
        }
        self.logic_data["lessons"].append(lesson)
        self.save_logic()

    def evaluate_logic(self, input_statement):
        results = []
        for lesson in self.logic_data["lessons"]:
            if input_statement in lesson["premise"]:
                results.append({
                    "conclusion": lesson["conclusion"],
                    "confidence": lesson["confidence"],
                    "source": lesson["source"]
                })
        if not results:
            return "I don’t have enough logic to evaluate that yet."
        return results
