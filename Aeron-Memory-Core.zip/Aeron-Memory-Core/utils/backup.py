
import os
import shutil
from datetime import datetime

def create_backup(file_path: str) -> str:
    """Create a backup of a file with timestamp"""
    if not os.path.exists(file_path):
        return ""
        
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = "backups"
    
    # Create backups directory if it doesn't exist
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    # Create backup filename
    filename = os.path.basename(file_path)
    backup_path = os.path.join(backup_dir, f"{filename}.{timestamp}.bak")
    
    # Create backup
    shutil.copy2(file_path, backup_path)
    return backup_path

def backup_project_files():
    """Backup all important project files"""
    files_to_backup = [
        "Aeron_Memory_Core/main.py",
        "core_engines/logic.py",
        "memory/memory.py"
    ]
    
    backups = []
    for file_path in files_to_backup:
        backup_path = create_backup(file_path)
        if backup_path:
            backups.append(backup_path)
    
    return backups
