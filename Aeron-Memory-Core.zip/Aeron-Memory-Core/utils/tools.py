def write_to_file(file_path: str, content: str):
  with open(file_path, 'w') as f:
      f.write(content)

def append_to_file(file_path: str, content: str):
  with open(file_path, 'a') as f:
      f.write(content)