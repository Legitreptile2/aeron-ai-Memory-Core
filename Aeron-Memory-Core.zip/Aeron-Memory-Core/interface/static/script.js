
document.getElementById('ai-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const response = await fetch('/interact', {
        method: 'POST',
        body: new FormData(form)
    });
    const data = await response.json();
    
    document.getElementById('ai-response').innerHTML = `
        <h3>AI Response:</h3>
        <pre>${JSON.stringify(data.ai_response, null, 2)}</pre>
    `;
    
    document.getElementById('openai-response').innerHTML = `
        <h3>Custom AI Response:</h3>
        <pre>${JSON.stringify(data.openai_response, null, 2)}</pre>
    `;
});
