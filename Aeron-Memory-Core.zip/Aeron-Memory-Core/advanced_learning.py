from typing import Dict, Any
import random

class ScenarioGenerator:
    def __init__(self):
        self.patterns = []
        self.generated_algorithms = []

    def learn_pattern(self, input_data: Dict[str, Any], output_data: Dict[str, Any]) -> None:
        self.patterns.append({
            'input': input_data,
            'output': output_data,
            'weight': 1.0
        })

    def generate_scenario(self, context: Dict[str, Any]) -> Dict[str, Any]:
        if not self.patterns:
            return {"error": "No patterns learned yet"}

        new_scenario = {}
        weighted_patterns = random.choices(
            self.patterns, 
            weights=[p['weight'] for p in self.patterns],
            k=3
        )

        for pattern in weighted_patterns:
            for key, value in pattern['input'].items():
                if key not in new_scenario:
                    new_scenario[key] = value

        return new_scenario

    def create_algorithm(self, scenario: Dict[str, Any]) -> str:
        algorithm_template = f"""
def dynamic_algorithm_{len(self.generated_algorithms)}(input_data):
    if {self._generate_condition(scenario)}:
        return {self._generate_action(scenario)}
    return None
"""
        self.generated_algorithms.append(algorithm_template)
        return algorithm_template

    def _generate_condition(self, scenario: Dict[str, Any]) -> str:
        conditions = []
        for key, value in scenario.items():
            if isinstance(value, (int, float)):
                conditions.append(f"input_data.get('{key}', 0) >= {value}")
            else:
                conditions.append(f"'{value}' in str(input_data.get('{key}', ''))")
        return " and ".join(conditions) if conditions else "True"

    def _generate_action(self, scenario: Dict[str, Any]) -> str:
        return f"dict(scenario={scenario}, action='generated')"

class MultiAlgorithmAI:
    def __init__(self):
        self.scenario_generator = ScenarioGenerator()
        self.learning_rate = 0.1
        self.knowledge_base = {
            "what is your name": "My name is Aeron.",
            "who are you": "I am Aeron, an AI developed to learn and adapt.",
            "what can you do": "I can learn from patterns, respond to questions, and evolve over time.",
            "how are you": "I'm doing well, thank you for asking!"
        }

    def process_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        user_text = input_data.get("text", "").lower().strip("?!. ")

        # Attempt to find a matching answer
        response_text = self.knowledge_base.get(user_text)

        if not response_text:
            response_text = "I'm still learning and don't know how to answer that yet."

        # Learn the pattern
        self.scenario_generator.learn_pattern(input_data, {"response": response_text})

        # Confidence analysis
        analysis_results = {
            "match_score": 0.85,
            "understanding_score": 0.9,
            "completeness_score": 0.75,
            "uncertainty_penalty": 0.1
        }

        confidence = calculate_confidence(user_text, analysis_results)

        return {
            'response': response_text,
            'confidence': confidence,
            'algorithms_count': len(self.scenario_generator.generated_algorithms)
        }

def calculate_confidence(input_text, analysis_results):
    match_score = analysis_results.get('match_score', 0)
    understanding_score = analysis_results.get('understanding_score', 0)
    completeness_score = analysis_results.get('completeness_score', 0)
    uncertainty_penalty = analysis_results.get('uncertainty_penalty', 0)

    confidence = (
        0.4 * match_score +
        0.3 * understanding_score +
        0.3 * completeness_score -
        0.2 * uncertainty_penalty
    )
    return round(confidence, 6)
