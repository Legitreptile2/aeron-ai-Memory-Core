from aeron_self import AeronSelf
import os
import sys
import json
import traceback  # Added for full error logging
from flask import Flask, request, render_template, redirect, url_for, flash
from flask_login import LoginManager, login_user, login_required, logout_user

# Add the current directory to the Python path (for importing aeron and auth)
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

from aeron import Aeron  # Make sure aeron.py contains a class named Aeron
from auth import User, authorized_user  # Make sure auth.py has these

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Set up login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Initialize Aeron instance
aeron = Aeron()

# Load Aeron memory if available
try:
    with open('data/chat_history.json', 'r') as f:
        chat_data = json.load(f)
        aeron.memory["last"] = chat_data.get("last", None)
except FileNotFoundError:
    print("No existing chat history found")

# User loader for Flask-Login
@login_manager.user_loader
def load_user(username):
    if username == authorized_user.username:
        return authorized_user
    return None

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if (request.form['username'] == authorized_user.username and 
            authorized_user.check_password(request.form['password'])):
            login_user(authorized_user)
            return redirect(url_for('interact'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/interact', methods=['GET', 'POST'])
@login_required
def interact():
    if request.method == 'POST':
        user_input = request.form['input']
        context = "User interacting via web interface"
        try:
            response = aeron.process(user_input, context)
        except Exception as e:
            print("⚠️ Error while processing user input:")
            traceback.print_exc()  # Print full traceback to debug
            response = "⚠️ Sorry, an error occurred while processing your input."
        return render_template('interact.html', response=response, user_input=user_input)
    return render_template('interact.html', response=None)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# Run the app
if __name__ == "__main__":
    aeron_self = AeronSelf()
    print(aeron_self.reflect_on_self())  # ✅ This should now work
    app.run(host="0.0.0.0", port=3000)