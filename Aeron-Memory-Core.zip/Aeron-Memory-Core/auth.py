from flask_login import UserMixin

class User(UserMixin):
    def __init__(self, username, password):
        self.username = username
        self._password = password

    def check_password(self, password):
        return self._password == password

    @property
    def id(self):
        return self.username  # Flask-Login uses this to identify the user

# Create a single authorized user
authorized_user = User("admin", "La051109")