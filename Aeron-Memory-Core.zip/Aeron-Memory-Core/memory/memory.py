import os
import json
from datetime import datetime

SHORT_TERM_MEMORY_DIR = "memory/short_term"
LONG_TERM_MEMORY_DIR = "memory/long_term"

os.makedirs(SHORT_TERM_MEMORY_DIR, exist_ok=True)
os.makedirs(LONG_TERM_MEMORY_DIR, exist_ok=True)

def save_memory(data, memory_type: str = "short_term") -> None:
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{timestamp}.txt"

    if memory_type == "short_term":
        filepath = os.path.join(SHORT_TERM_MEMORY_DIR, filename)
    else:
        filepath = os.path.join(LONG_TERM_MEMORY_DIR, filename)

    # Convert to JSON string if data is a dict
    if isinstance(data, dict):
        text = json.dumps(data, indent=2)
    else:
        text = str(data)

    with open(filepath, "w") as f:
        f.write(text)

def load_last_memory(memory_type: str = "short_term") -> str:
    directory = SHORT_TERM_MEMORY_DIR if memory_type == "short_term" else LONG_TERM_MEMORY_DIR
    files = sorted(os.listdir(directory), reverse=True)
    if not files:
        return "No memory found."

    latest_file = files[0]
    filepath = os.path.join(directory, latest_file)
    with open(filepath, "r") as f:
        return f.read()