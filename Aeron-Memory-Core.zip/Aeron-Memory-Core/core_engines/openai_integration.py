import os
from typing import Dict, Any, List
import json
import random

class CustomAIEngine:
    def __init__(self):
        self.chat_history = []
        self.knowledge_base = []
        self.learning_threshold = 0.7
        
    def load_chat_history(self, conversations: List[Dict]) -> None:
        """Load existing conversations into knowledge base"""
        for conv in conversations:
            self.knowledge_base.append({
                'input': conv.get('user_input', ''),
                'response': conv.get('ai_response', ''),
                'context': conv.get('context', '')
            })
    
    def process_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        user_input = input_data.get('input', '')
        
        # Find most relevant response from knowledge base
        best_response = self._find_best_match(user_input)
        confidence = self._calculate_confidence(user_input)
        
        # Generate response based on knowledge
        if best_response:
            response = self._adapt_response(best_response)
        else:
            response = self._generate_new_response(user_input)
            
        return {
            'response': response,
            'confidence': confidence,
            'source': 'custom_ai'
        }
    
    def _find_best_match(self, input_text: str) -> str:
        if not self.knowledge_base:
            return None
            
        # Simple matching based on common words
        input_words = set(input_text.lower().split())
        best_match = None
        best_score = 0
        
        for entry in self.knowledge_base:
            entry_words = set(entry['input'].lower().split())
            score = len(input_words.intersection(entry_words))
            if score > best_score:
                best_score = score
                best_match = entry['response']
                
        return best_match if best_score > 0 else None
    
    def _adapt_response(self, base_response: str) -> str:
        """Modify the response to make it unique"""
        # Add variations to make response unique
        variations = [
            "Based on my analysis, ",
            "From what I understand, ",
            "I would suggest that ",
            "My evaluation indicates that "
        ]
        return random.choice(variations) + base_response
    
    def _generate_new_response(self, input_text: str) -> str:
        return "I'm analyzing your request based on my custom knowledge base."
        
    def _calculate_confidence(self, input_text: str) -> float:
        if not self.knowledge_base:
            return 0.3
        return random.uniform(0.6, 0.9)
