from .advanced_learning import MultiAlgorithmAI

class LogicEngine:
    def __init__(self):
        self.multi_ai = MultiAlgorithmAI()
        self.priority_factors = {
            'safety': 0.8,
            'opportunity': 0.6,
            'efficiency': 0.5,
            'innovation': 0.4
        }

    def evaluate_facts(self, facts: str) -> str:
        facts_lower = facts.lower()
        analysis = []
        
        if "danger" in facts_lower or "risk" in facts_lower:
            analysis.append(("Safety concerns detected", self.priority_factors['safety']))
        if "opportunity" in facts_lower or "potential" in facts_lower:
            analysis.append(("Opportunity identified", self.priority_factors['opportunity']))
        if "efficient" in facts_lower or "optimize" in facts_lower:
            analysis.append(("Efficiency consideration", self.priority_factors['efficiency']))
        if "new" in facts_lower or "innovative" in facts_lower:
            analysis.append(("Innovation potential", self.priority_factors['innovation']))

        if not analysis:
            return "Insufficient data. Requesting more context."

        # Sort by priority and combine insights
        analysis.sort(key=lambda x: x[1], reverse=True)
        return " | ".join(f"{item[0]}" for item in analysis)

    def assess_risk(self, context: str) -> str:
        if any(word in context.lower() for word in ["high risk", "critical", "unstable"]):
            return "High risk situation. Strategic planning recommended."
        elif any(word in context.lower() for word in ["low risk", "safe", "secure"]):
            return "Low risk. Proceed with confidence."
        else:
            return "Risk level unknown. Proceed with awareness."

    def make_recommendation(self, facts: str, context: str) -> str:
        evaluation = self.evaluate_facts(facts)
        risk = self.assess_risk(context)
        
        # Process with advanced learning
        advanced_input = {
            'facts': facts,
            'context': context,
            'evaluation': evaluation,
            'risk': risk
        }
        
        ai_result = self.multi_ai.process_input(advanced_input)
        
        return f"Evaluation: {evaluation}\nRisk Assessment: {risk}\nAI Analysis: {ai_result}"
