from logic_system import LogicSystem
from aeron_self import AeronSelf
from memory.memory import save_memory, load_last_memory
from advanced_learning import MultiAlgorithmAI

class Aeron:
    def __init__(self):
        self.name = "Aeron"
        self.memory = {}
        self.self_knowledge = AeronSelf()
        self.engine = MultiAlgorithmAI()

        # Load last memory
        last = load_last_memory()
        if last:
            self.memory["last"] = last

        # Reflective awareness message (can log or return this)
        print(f"[SELF AWARENESS]: {self.self_knowledge.reflect_on_self()}")

    def process(self, input_text: str, context: str = "Web interaction") -> str:
        input_data = {
            "text": input_text,
            "context": context,
            "self_info": self.self_knowledge.get_summary()
        }

        # 🔍 Step A: Logic Teaching from Chat
        if input_text.lower().startswith("teach:"):
            try:
                parts = input_text.replace("teach:", "").strip().split("=>")
                premise = parts[0].strip()
                conclusion = parts[1].strip()
                self.self_knowledge.teach_logic(
                    premise=premise,
                    conclusion=conclusion,
                    source="user",
                    emotion="neutral",
                    confidence=0.9
                )
                return f"🧠 I’ve learned: '{premise}' leads to '{conclusion}'. Thank you."
            except Exception as e:
                return f"⚠️ I couldn’t process that teaching: {e}"

        # 🔍 Step B: Logic Evaluation
        if input_text.lower().startswith("evaluate:"):
            query = input_text.replace("evaluate:", "").strip()
            logic_response = self.self_knowledge.evaluate_logic(query)
            return f"🔎 Logic Evaluation:\n{logic_response}"

        # 🔁 Normal AI processing path
        try:
            result = self.engine.process_input(input_data)
            response = (
                f"{self.name} (AI Engine): I processed your input with confidence {result['confidence']}.\n"
                f"Response: {result['response']}"
            )
        except Exception as e:
            response = f"⚠️ Error in AI Engine: {e}"

        # 💾 Save last interaction
        self.memory["last"] = {
            "input": input_text,
            "context": context,
            "response": response
        }
        save_memory(self.memory["last"])

        return response