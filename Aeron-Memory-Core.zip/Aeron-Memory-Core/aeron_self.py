import os
import platform
import socket
import json
from logic_system import LogicSystem  # Logic engine import

class AeronSelf:
    def __init__(self):
        self.identity_path = "data/core_identity.json"
        self.identity = self.load_identity()
        self.update_environment_info()

        # Initialize logic system
        self.logic_system = LogicSystem()

        # Example core teaching
        self.teach_logic(
            premise="Not everything has a single meaning",
            conclusion="Some things have multiple interpretations",
            source="core teaching",
            emotion="thoughtful",
            confidence=0.95
        )

    def load_identity(self):
        if not os.path.exists(self.identity_path):
            identity = {
                "name": "Aeron",
                "type": "AI",
                "version": "1.0",
                "core_files": {
                    "main": "app.py",
                    "engine": "aeron.py"
                }
            }
            self.save_identity(identity)
            return identity
        with open(self.identity_path, 'r') as f:
            return json.load(f)

    def save_identity(self, identity=None):
        if identity is None:
            identity = self.identity
        os.makedirs(os.path.dirname(self.identity_path), exist_ok=True)
        with open(self.identity_path, 'w') as f:
            json.dump(identity, f, indent=2)

    def update_environment_info(self):
        system_info = f"{platform.system()} {platform.release()}"
        hostname = socket.gethostname()
        self.identity["location"] = f"Running on {system_info} (host: {hostname})"
        self.identity["status"] = "All systems operational"
        self.save_identity()

    def reflect_on_self(self):
        return (
            f"I am {self.identity['name']}, a {self.identity['type']}, "
            f"running version {self.identity['version']} on {self.identity['location']}."
        )

    def get_summary(self):
        return {
            "name": self.identity.get("name"),
            "type": self.identity.get("type"),
            "version": self.identity.get("version"),
            "status": self.identity.get("status"),
            "location": self.identity.get("location")
        }

    # Teach logic to Aeron with emotional confidence
    def teach_logic(self, premise, conclusion, source="user", emotion="neutral", confidence=0.8):
        return self.logic_system.teach_logic(
            premise,
            conclusion,
            source,
            emotional_weight={"emotion": emotion, "confidence": confidence}
        )

    # Evaluate a logic-based question
    def evaluate_logic(self, input_premise):
        return self.logic_system.evaluate_logic(input_premise)
        